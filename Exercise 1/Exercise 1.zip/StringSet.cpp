#include "StringSet.h"
#include <string>
using std::string;

// Implementation of each class methods

//constructor
StringSet::StringSet(){
  
}

//inserting a string, returning a bool
bool StringSet::insert(string st){

  return false;
}

//removes a string
void StringSet::remove(string st){

}

//returns the size of the string
int StringSet::size(){

  return 0;
}

//finds a string and returns a num
int StringSet::find(string st){

  return 0;
}
